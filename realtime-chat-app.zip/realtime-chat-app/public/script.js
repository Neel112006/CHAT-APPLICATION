const username = prompt("Enter your name:") || "Anonymous";

const socket = io();

const form = document.getElementById("form");
const input = document.getElementById("input");
const messages = document.getElementById("messages");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const trimmedMessage = input.value.trim();

  if (trimmedMessage && trimmedMessage.length < 200) {
    // Send both username and message
    socket.emit("chat message", {
      username: username,
      message: trimmedMessage
    });
    input.value = "";
  } else {
    alert("Message is either empty or too long (200+ characters).");
  }
});

socket.on("chat message", (msg) => {
  const item = document.createElement("li");
  const now = new Date().toLocaleTimeString();
  item.textContent = `[${now}] ${msg}`;
  messages.appendChild(item);
  messages.scrollTop = messages.scrollHeight;
});

